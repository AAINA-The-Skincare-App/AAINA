//
//  SkinConditionSectionView.swift
//  AAINA
//

import UIKit

final class SkinConditionSectionView: UIView {

    // MARK: - Outlets
    @IBOutlet private weak var pillsContainerStack: UIStackView!
    @IBOutlet private weak var concernsContainerStack: UIStackView!

    // MARK: - Callbacks
    var onConditionSelected: ((String) -> Void)?
    var onConcernsChanged: ((Set<String>) -> Void)?

    // MARK: - State
    private let skinConditions = ["Balanced", "Oily", "Dry", "Combination", "Sensitive"]
    private let skinConcerns   = ["Breakouts", "Redness", "Dark spots", "Fine lines",
                                  "Texture", "Dullness", "None"]

    private var skinConditionButtons = [UIButton]()
    private var concernButtons       = [UIButton]()

    private(set) var selectedCondition: String = "" {
        didSet { refreshConditionButtons(); onConditionSelected?(selectedCondition) }
    }
    private(set) var selectedConcerns = Set<String>() {
        didSet { refreshConcernButtons(); onConcernsChanged?(selectedConcerns) }
    }

    // MARK: - Factory
    static func create() -> SkinConditionSectionView {
        let views = Bundle.main.loadNibNamed("SkinConditionSectionView", owner: nil, options: nil)!
        return views.first as! SkinConditionSectionView
    }

    override func awakeFromNib() {
        super.awakeFromNib()
        buildConditionPills()
        buildConcernPills()
    }

    // MARK: - Build pills
    private func buildConditionPills() {
        skinConditions.forEach { title in
            let btn = makePill(title: title)
            btn.addTarget(self, action: #selector(conditionTapped(_:)), for: .touchUpInside)
            skinConditionButtons.append(btn)
        }
        layoutPillsInto(pillsContainerStack, buttons: skinConditionButtons)
    }

    private func buildConcernPills() {
        skinConcerns.forEach { title in
            let btn = makePill(title: title)
            btn.addTarget(self, action: #selector(concernTapped(_:)), for: .touchUpInside)
            concernButtons.append(btn)
        }
        layoutPillsInto(concernsContainerStack, buttons: concernButtons)
    }

    private func layoutPillsInto(_ stack: UIStackView, buttons: [UIButton]) {
        stack.axis = .vertical
        stack.spacing = 10
        stack.alignment = .leading

        var rowButtons = [UIButton]()
        var rowWidth: CGFloat = 0
        let maxWidth: CGFloat = (window?.windowScene?.screen.bounds.width ?? 390) - 80

        func flushRow() {
            let row = UIStackView(arrangedSubviews: rowButtons)
            row.axis = .horizontal
            row.spacing = 8
            stack.addArrangedSubview(row)
            rowButtons = []
            rowWidth = 0
        }

        for btn in buttons {
            let bw = btn.intrinsicContentSize.width + 36 + 8
            if rowWidth + bw > maxWidth && !rowButtons.isEmpty { flushRow() }
            rowButtons.append(btn)
            rowWidth += bw
        }
        if !rowButtons.isEmpty { flushRow() }
    }

    private func makePill(title: String) -> UIButton {
        var cfg = UIButton.Configuration.plain()
        cfg.title = title
        cfg.baseForegroundColor = .ainaTextPrimary
        cfg.contentInsets = NSDirectionalEdgeInsets(top: 8, leading: 18, bottom: 8, trailing: 18)
        cfg.titleTextAttributesTransformer = UIConfigurationTextAttributesTransformer { attrs in
            var a = attrs
            a.font = .systemFont(ofSize: 14, weight: .medium)
            return a
        }
        let btn = UIButton(configuration: cfg)
        btn.backgroundColor = UIColor.ainaGlassElevated
        btn.layer.cornerRadius = 20
        btn.layer.borderWidth = 1
        btn.layer.borderColor = UIColor.ainaTextTertiary.withAlphaComponent(0.4).cgColor
        return btn
    }

    // MARK: - Actions
    @objc private func conditionTapped(_ sender: UIButton) {
        let title = sender.configuration?.title ?? ""
        selectedCondition = (selectedCondition == title) ? "" : title
    }

    @objc private func concernTapped(_ sender: UIButton) {
        let title = sender.configuration?.title ?? ""
        if title == "None" {
            selectedConcerns = selectedConcerns.contains("None") ? [] : ["None"]
        } else {
            selectedConcerns.remove("None")
            if selectedConcerns.contains(title) { selectedConcerns.remove(title) }
            else { selectedConcerns.insert(title) }
        }
    }

    // MARK: - Refresh
    private func refreshConditionButtons() {
        for btn in skinConditionButtons {
            let isSelected = btn.configuration?.title == selectedCondition
            applyPillStyle(btn, selected: isSelected)
        }
    }

    private func refreshConcernButtons() {
        for btn in concernButtons {
            let title = btn.configuration?.title ?? ""
            applyPillStyle(btn, selected: selectedConcerns.contains(title))
        }
    }

    private func applyPillStyle(_ btn: UIButton, selected: Bool) {
        btn.backgroundColor = selected ? .ainaDustyRose : UIColor.ainaGlassElevated
        btn.layer.borderColor = selected
            ? UIColor.ainaDustyRose.cgColor
            : UIColor.ainaTextTertiary.withAlphaComponent(0.4).cgColor
        btn.configuration?.baseForegroundColor = selected ? .white : .ainaTextPrimary
    }
}
