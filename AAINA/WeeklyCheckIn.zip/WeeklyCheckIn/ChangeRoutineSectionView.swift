//
//  ChangeRoutineSectionView.swift
//  AAINA
//

import UIKit

final class ChangeRoutineSectionView: UIView {

    // MARK: - Outlets
    @IBOutlet private weak var cardView: UIView!
    @IBOutlet private weak var yesButton: UIButton!
    @IBOutlet private weak var noButton: UIButton!
    @IBOutlet private weak var reasonContainer: UIView!
    @IBOutlet private weak var reasonTextView: UITextView!
    @IBOutlet private weak var reasonPlaceholder: UILabel!
    @IBOutlet private weak var warningLabel: UILabel!

    // MARK: - Public
    var routineStartDate: Date = Date()
    var onChangeDecision: ((Bool, String) -> Void)?
    private(set) var wantsChange: Bool = false
    var reason: String { reasonTextView.text ?? "" }

    private let minimumWeeks = 4

    // MARK: - Factory
    static func create() -> ChangeRoutineSectionView {
        let views = Bundle.main.loadNibNamed("ChangeRoutineSectionView", owner: nil, options: nil)!
        return views.first as! ChangeRoutineSectionView
    }

    override func awakeFromNib() {
        super.awakeFromNib()
        cardView.backgroundColor = .ainaGlassElevated
        cardView.layer.cornerRadius = 16
        cardView.layer.shadowColor = UIColor.ainaCardShadowColor.cgColor
        cardView.layer.shadowOpacity = 0.08
        cardView.layer.shadowOffset = CGSize(width: 0, height: 2)
        cardView.layer.shadowRadius = 8
        styleButtons()
        configureReasonArea()
        configureWarning()
        reasonContainer.isHidden = true
        yesButton.addTarget(self, action: #selector(yesTapped), for: .touchUpInside)
        noButton.addTarget(self, action: #selector(noTapped), for: .touchUpInside)
        setUI(wantsChange: false)
    }

    // MARK: - Style
    private func styleButtons() {
        for btn in [yesButton, noButton] {
            btn?.layer.cornerRadius = 12
            btn?.titleLabel?.font = .systemFont(ofSize: 15, weight: .medium)
        }
    }

    private func configureReasonArea() {
        reasonTextView.backgroundColor = .clear
        reasonTextView.font = .systemFont(ofSize: 14)
        reasonTextView.textColor = .ainaTextPrimary
        reasonTextView.isScrollEnabled = false
        reasonTextView.delegate = self

        reasonPlaceholder.text = "e.g. My skin has stopped responding, I want to try new products..."
        reasonPlaceholder.font = .systemFont(ofSize: 14)
        reasonPlaceholder.textColor = .ainaTextTertiary
        reasonPlaceholder.numberOfLines = 0
    }

    private func configureWarning() {
        warningLabel.text = "⚠️  Give your routine more time. Most routines need at least 4 weeks to show results. Consider waiting before making changes."
        warningLabel.font = .systemFont(ofSize: 13)
        warningLabel.textColor = UIColor.ainaSoftRed
        warningLabel.numberOfLines = 0
        warningLabel.backgroundColor = UIColor.ainaSoftRed.withAlphaComponent(0.1)
        warningLabel.layer.cornerRadius = 10
        warningLabel.layer.masksToBounds = true
        warningLabel.isHidden = true
    }

    // MARK: - Actions
    @IBAction private func yesTapped() {
        wantsChange = true
        setUI(wantsChange: true)
        let weeks = weeksSince(routineStartDate)
        warningLabel.isHidden = weeks >= minimumWeeks
        onChangeDecision?(true, reason)
    }

    @IBAction private func noTapped() {
        wantsChange = false
        setUI(wantsChange: false)
        onChangeDecision?(false, "")
    }

    private func setUI(wantsChange: Bool) {
        UIView.animate(withDuration: 0.25) {
            self.reasonContainer.isHidden = !wantsChange

            self.yesButton.backgroundColor = wantsChange
                ? .ainaDustyRose : UIColor.ainaTextTertiary.withAlphaComponent(0.2)
            self.yesButton.setTitleColor(wantsChange ? .white : .ainaTextSecondary, for: .normal)

            self.noButton.backgroundColor = wantsChange
                ? UIColor.ainaTextTertiary.withAlphaComponent(0.2) : .ainaDustyRose
            self.noButton.setTitleColor(wantsChange ? .ainaTextSecondary : .white, for: .normal)
        }
    }

    // MARK: - Helpers
    private func weeksSince(_ date: Date) -> Int {
        Calendar.current.dateComponents([.weekOfYear], from: date, to: Date()).weekOfYear ?? 0
    }
}

// MARK: - UITextViewDelegate
extension ChangeRoutineSectionView: UITextViewDelegate {
    func textViewDidChange(_ textView: UITextView) {
        reasonPlaceholder.isHidden = !textView.text.isEmpty
        onChangeDecision?(wantsChange, reason)
    }
}
