//
//  ProductChangesSectionView.swift
//  AAINA
//

import UIKit

final class ProductChangesSectionView: UIView {

    // MARK: - Outlets
    @IBOutlet private weak var productCard: UIView!
    @IBOutlet private weak var productRowsStack: UIStackView!
    @IBOutlet private weak var addProductButton: UIButton!

    // MARK: - Callbacks
    var onProductChangesUpdated: (([(name: String, isAdded: Bool)]) -> Void)?

    // MARK: - State
    private(set) var productChanges: [(name: String, isAdded: Bool)] = []

    // Reference to VC for presenting alert
    weak var presentingViewController: UIViewController?

    // MARK: - Factory
    static func create() -> ProductChangesSectionView {
        let views = Bundle.main.loadNibNamed("ProductChangesSectionView", owner: nil, options: nil)!
        return views.first as! ProductChangesSectionView
    }

    override func awakeFromNib() {
        super.awakeFromNib()
        productCard.backgroundColor = .ainaGlassElevated
        productCard.layer.cornerRadius = 16
        productCard.layer.shadowColor = UIColor.ainaCardShadowColor.cgColor
        productCard.layer.shadowOpacity = 0.08
        productCard.layer.shadowOffset = CGSize(width: 0, height: 2)
        productCard.layer.shadowRadius = 8
        productRowsStack.axis = .vertical
        productRowsStack.spacing = 8
        addProductButton.addTarget(self, action: #selector(addProductTapped), for: .touchUpInside)
    }

    // MARK: - Actions
    @IBAction private func addProductTapped() {
        guard let vc = presentingViewController else { return }
        let alert = UIAlertController(title: "Add Product Change",
                                      message: "Enter the product name",
                                      preferredStyle: .alert)
        alert.addTextField { $0.placeholder = "Product name" }

        alert.addAction(UIAlertAction(title: "Added", style: .default) { [weak self] _ in
            guard let name = alert.textFields?.first?.text, !name.isEmpty else { return }
            self?.addProductRow(name: name, isAdded: true)
        })
        alert.addAction(UIAlertAction(title: "Removed", style: .destructive) { [weak self] _ in
            guard let name = alert.textFields?.first?.text, !name.isEmpty else { return }
            self?.addProductRow(name: name, isAdded: false)
        })
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        vc.present(alert, animated: true)
    }

    // MARK: - Helpers
    func addProductRow(name: String, isAdded: Bool) {
        productChanges.append((name: name, isAdded: isAdded))

        let row = UIView()
        row.backgroundColor = isAdded
            ? UIColor.ainaSageGreen.withAlphaComponent(0.12)
            : UIColor.ainaSoftRed.withAlphaComponent(0.12)
        row.layer.cornerRadius = 12
        row.translatesAutoresizingMaskIntoConstraints = false
        row.heightAnchor.constraint(equalToConstant: 50).isActive = true

        let dotView = UIView()
        dotView.translatesAutoresizingMaskIntoConstraints = false
        dotView.backgroundColor = isAdded ? UIColor.ainaSageGreen : UIColor.ainaSoftRed
        dotView.layer.cornerRadius = 12
        dotView.widthAnchor.constraint(equalToConstant: 24).isActive = true
        dotView.heightAnchor.constraint(equalToConstant: 24).isActive = true

        let dotLabel = UILabel()
        dotLabel.text = isAdded ? "+" : "−"
        dotLabel.textColor = .white
        dotLabel.font = .systemFont(ofSize: 14, weight: .bold)
        dotLabel.textAlignment = .center
        dotLabel.translatesAutoresizingMaskIntoConstraints = false
        dotView.addSubview(dotLabel)
        NSLayoutConstraint.activate([
            dotLabel.centerXAnchor.constraint(equalTo: dotView.centerXAnchor),
            dotLabel.centerYAnchor.constraint(equalTo: dotView.centerYAnchor)
        ])

        let nameLabel = UILabel()
        nameLabel.text = name
        nameLabel.font = .systemFont(ofSize: 14, weight: .medium)
        nameLabel.textColor = .ainaTextPrimary
        nameLabel.translatesAutoresizingMaskIntoConstraints = false

        let subLabel = UILabel()
        subLabel.text = isAdded ? "Added this week" : "Removed this week"
        subLabel.font = .systemFont(ofSize: 12)
        subLabel.textColor = isAdded ? UIColor.ainaSageGreen : UIColor.ainaSoftRed
        subLabel.translatesAutoresizingMaskIntoConstraints = false

        let removeBtn = UIButton(type: .system)
        removeBtn.setImage(UIImage(systemName: "xmark"), for: .normal)
        removeBtn.tintColor = .ainaTextSecondary
        removeBtn.translatesAutoresizingMaskIntoConstraints = false
        let idx = productChanges.count - 1
        removeBtn.tag = idx
        removeBtn.addTarget(self, action: #selector(removeRow(_:)), for: .touchUpInside)

        row.addSubview(dotView)
        row.addSubview(nameLabel)
        row.addSubview(subLabel)
        row.addSubview(removeBtn)

        NSLayoutConstraint.activate([
            dotView.leadingAnchor.constraint(equalTo: row.leadingAnchor, constant: 12),
            dotView.centerYAnchor.constraint(equalTo: row.centerYAnchor),
            nameLabel.leadingAnchor.constraint(equalTo: dotView.trailingAnchor, constant: 10),
            nameLabel.topAnchor.constraint(equalTo: row.topAnchor, constant: 8),
            subLabel.leadingAnchor.constraint(equalTo: nameLabel.leadingAnchor),
            subLabel.topAnchor.constraint(equalTo: nameLabel.bottomAnchor, constant: 2),
            removeBtn.trailingAnchor.constraint(equalTo: row.trailingAnchor, constant: -12),
            removeBtn.centerYAnchor.constraint(equalTo: row.centerYAnchor)
        ])

        productRowsStack.addArrangedSubview(row)
        onProductChangesUpdated?(productChanges)
    }

    @objc private func removeRow(_ sender: UIButton) {
        let idx = sender.tag
        guard idx < productChanges.count else { return }
        productChanges.remove(at: idx)
        let views = productRowsStack.arrangedSubviews
        if idx < views.count {
            productRowsStack.removeArrangedSubview(views[idx])
            views[idx].removeFromSuperview()
        }
        onProductChangesUpdated?(productChanges)
    }
}
